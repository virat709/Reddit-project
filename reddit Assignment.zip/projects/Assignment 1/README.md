# Reddit User Persona Generator

This Python project takes a Reddit user profile URL, scrapes up to 20 posts and 20 comments from that user, and generates a detailed user persona using OpenAI's GPT-3.5. The persona includes descriptions of the user's interests, tone, beliefs, habits, and more, with citations referencing the exact posts and comments.

## Features

- Input a Reddit user profile URL
- Scrape up to 20 posts and 20 comments using the Reddit API (`praw`)
- Generate a detailed user persona using OpenAI's GPT-3.5
- Save the persona to a text file named `{username}_persona.txt`
- Clean, modular, and easy-to-understand code

## Requirements

- Python 3.7+
- Reddit API credentials (`REDDIT_CLIENT_ID`, `REDDIT_CLIENT_SECRET`, `REDDIT_USER_AGENT`)
- OpenAI API key (`OPENAI_API_KEY`)

## Setup

1. Clone this repository or download the files.

2. Create a virtual environment (recommended):

```bash
python -m venv venv
source venv/bin/activate  # On Windows use: venv\Scripts\activate
```

3. Install dependencies:

```bash
pip install -r requirements.txt
```

4. Create a `.env` file in the project root based on `.env.example` and add your API keys:

```
REDDIT_CLIENT_ID=your_reddit_client_id
REDDIT_CLIENT_SECRET=your_reddit_client_secret
REDDIT_USER_AGENT=your_reddit_user_agent
OPENAI_API_KEY=your_openai_api_key
```

## Usage

Run the main script:

```bash
python main.py
```

Enter the Reddit user profile URL when prompted, for example:

```
https://www.reddit.com/user/kojied/
```

The script will fetch the user's posts and comments, generate a persona, and save it to `kojied_persona.txt`.

## Notes

- Make sure your Reddit API credentials have the necessary permissions.
- The OpenAI API key should have access to the GPT-3.5 model.
- The output file will be saved in the current working directory.

## License

This project is provided as-is for educational purposes.
