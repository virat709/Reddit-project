import os
import re
from typing import List, Dict, Tuple
from dotenv import load_dotenv
import praw
import openai


def extract_username_from_url(url: str) -> str:
    """
    Extract the Reddit username from the profile URL.
    """
    pattern = r'reddit\.com\/user\/([A-Za-z0-9_-]+)'
    match = re.search(pattern, url)
    if not match:
        raise ValueError("Invalid Reddit user URL")
    return match.group(1)


def fetch_user_content(
    reddit: praw.Reddit, username: str, max_posts: int = 20, max_comments: int = 20
) -> Tuple[List[Dict], List[Dict]]:
    """
    Fetch up to max_posts submissions and max_comments comments for the given username.
    Returns two lists of dicts with 'title' and 'body' for posts, and 'body' for comments.
    """
    user = reddit.redditor(username)

    posts = []
    try:
        for submission in user.submissions.new(limit=max_posts):
            posts.append({
                "title": submission.title,
                "body": submission.selftext,
                "url": submission.url,
                "permalink": f"https://reddit.com{submission.permalink}"
            })
    except Exception as e:
        print(f"Error fetching posts: {e}")

    comments = []
    try:
        for comment in user.comments.new(limit=max_comments):
            comments.append({
                "body": comment.body,
                "permalink": f"https://reddit.com{comment.permalink}"
            })
    except Exception as e:
        print(f"Error fetching comments: {e}")

    return posts, comments


def generate_persona_with_openai(
    username: str, posts: List[Dict], comments: List[Dict]
) -> str:
    """
    Generate a detailed user persona using OpenAI ChatCompletion.
    The persona should describe interests, tone, beliefs, habits, etc.
    Each characteristic should be cited with the exact post/comment.
    """
    openai.api_key = os.getenv("OPENAI_API_KEY")

    # Prepare the content text with citations
    content_lines = []
    content_lines.append(f"Reddit user: {username}\n")
    content_lines.append("Posts:\n")
    for i, post in enumerate(posts, 1):
        title = post['title']
        body = post['body']
        url = post['permalink']
        content_lines.append(f"Post {i} Title: {title}\nPost {i} Body: {body}\nURL: {url}\n")

    content_lines.append("\nComments:\n")
    for i, comment in enumerate(comments, 1):
        body = comment['body']
        url = comment['permalink']
        content_lines.append(f"Comment {i}: {body}\nURL: {url}\n")

    combined_content = "\n".join(content_lines)

    system_prompt = (
        "You are an expert analyst who creates detailed user personas based on Reddit posts and comments. "
        "Analyze the content carefully and describe the user's interests, tone, beliefs, habits, and other personality traits. "
        "For every characteristic you mention, cite the exact post or comment that supports it by referencing the text and URL. "
        "Be detailed and insightful."
    )

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": combined_content}
    ]

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=messages,
        max_tokens=1000,
        temperature=0.7,
        n=1,
        stop=None,
    )

    persona_text = response.choices[0].message['content'].strip()
    return persona_text


def save_persona_to_file(username: str, persona_text: str) -> None:
    """
    Save the persona text to a file named {username}_persona.txt
    """
    filename = f"{username}_persona.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(persona_text)


def main():
    load_dotenv()

    reddit_client_id = os.getenv("REDDIT_CLIENT_ID")
    reddit_client_secret = os.getenv("REDDIT_CLIENT_SECRET")
    reddit_user_agent = os.getenv("REDDIT_USER_AGENT")

    if not all([reddit_client_id, reddit_client_secret, reddit_user_agent]):
        print("Please set REDDIT_CLIENT_ID, REDDIT_CLIENT_SECRET, and REDDIT_USER_AGENT in your .env file.")
        return

    if not os.getenv("OPENAI_API_KEY"):
        print("Please set OPENAI_API_KEY in your .env file.")
        return

    reddit_url = input("Enter Reddit user profile URL: ").strip()
    try:
        username = extract_username_from_url(reddit_url)
    except ValueError as e:
        print(e)
        return

    reddit = praw.Reddit(
        client_id=reddit_client_id,
        client_secret=reddit_client_secret,
        user_agent=reddit_user_agent,
    )

    print(f"Fetching posts and comments for user: {username}...")
    posts, comments = fetch_user_content(reddit, username)

    print("Generating user persona with OpenAI...")
    persona_text = generate_persona_with_openai(username, posts, comments)

    save_persona_to_file(username, persona_text)

    print("Done!")


if __name__ == "__main__":
    main()
