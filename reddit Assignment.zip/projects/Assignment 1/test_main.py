import unittest
from unittest.mock import patch, MagicMock
import main


class TestRedditUserPersona(unittest.TestCase):

    def test_extract_username_from_url_valid(self):
        url = "https://www.reddit.com/user/kojied/"
        username = main.extract_username_from_url(url)
        self.assertEqual(username, "kojied")

    def test_extract_username_from_url_invalid(self):
        url = "https://www.reddit.com/r/python/"
        with self.assertRaises(ValueError):
            main.extract_username_from_url(url)

    @patch("main.praw.Reddit")
    def test_fetch_user_content_success(self, mock_reddit_class):
        mock_reddit = mock_reddit_class.return_value
        mock_user = MagicMock()
        mock_reddit.redditor.return_value = mock_user

        # Mock submissions
        mock_submission = MagicMock()
        mock_submission.title = "Test Post"
        mock_submission.selftext = "Post content"
        mock_submission.url = "http://example.com"
        mock_submission.permalink = "/r/test/comments/123"
        mock_user.submissions.new.return_value = [mock_submission] * 2

        # Mock comments
        mock_comment = MagicMock()
        mock_comment.body = "Test comment"
        mock_comment.permalink = "/r/test/comments/456"
        mock_user.comments.new.return_value = [mock_comment] * 2

        posts, comments = main.fetch_user_content(mock_reddit, "kojied", max_posts=2, max_comments=2)
        self.assertEqual(len(posts), 2)
        self.assertEqual(len(comments), 2)
        self.assertEqual(posts[0]["title"], "Test Post")
        self.assertEqual(comments[0]["body"], "Test comment")

    @patch("main.openai.ChatCompletion.create")
    def test_generate_persona_with_openai(self, mock_chat_create):
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message = {"content": "Persona text"}
        mock_chat_create.return_value = mock_response

        posts = [{"title": "Post1", "body": "Body1", "permalink": "url1"}]
        comments = [{"body": "Comment1", "permalink": "url2"}]

        persona = main.generate_persona_with_openai("kojied", posts, comments)
        self.assertEqual(persona, "Persona text")

    def test_save_persona_to_file(self):
        username = "testuser"
        persona_text = "This is a test persona."
        main.save_persona_to_file(username, persona_text)

        filename = f"{username}_persona.txt"
        with open(filename, "r", encoding="utf-8") as f:
            content = f.read()
        self.assertEqual(content, persona_text)


if __name__ == "__main__":
    unittest.main()
